// Approximate time - 1 hour

#pragma once

#include <cstdint>

const uint32_t invertBitSequence(const uint32_t inputNumber);